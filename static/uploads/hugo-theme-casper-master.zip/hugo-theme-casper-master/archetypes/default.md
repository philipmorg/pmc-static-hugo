+++
author = ""
comments = true	# set false to hide Disqus
date = "{{ .Date }}"
draft = true
image = ""
menu = ""		# set "main" to add this content to the main menu
share = true	# set false to hide share buttons
slug = "post-title"
tags = ["tag1","tag2"]
title = ""
+++